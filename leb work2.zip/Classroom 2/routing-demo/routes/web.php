<?php

use Illuminate\Support\Facades\Route;

// Program 1: Simple Route
Route::get('/hello', function () {
    return 'Hello World';
});

// Program 2: HTML Route
Route::get('/about', function () {
    return '<h1>About Us</h1>';
});

// Program 3: Route with Parameter
Route::get('/user/{name}', function ($name) {
    return 'Welcome ' . $name;
});

// Program 4: Optional Parameter
Route::get('/student/{name?}', function ($name = 'Student') {
    return 'Welcome ' . $name;
});

// Program 5: Multiple Parameters
Route::get('/student-info/{name}/{id}', function ($name, $id) {
    return 'Name: ' . $name . ' ID: ' . $id;
});

// Program 6: View Route
Route::get('/about-page', function () {
    return view('about');
});