<!DOCTYPE html>
<html>
<head>
    <title>About Page</title>
</head>
<body>
    <h1>Welcome to About Page</h1>
    <p>This is my Laravel project.</p>
</body>
</html><?php /**PATH C:\laragon\www\7114\Classroom 2\routing-demo\resources\views/about.blade.php ENDPATH**/ ?>