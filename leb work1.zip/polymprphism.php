<?php

class Fruit
{
    public $name;
    public $color;

    public function __construct($name, $color)
    {
        $this->name = $name;
        $this->color = $color;
    }

    public function intro()
    {
        echo "A $this->name is a fruit and the color of the fruit is $this->color.";
    }
}

class Cherry extends Fruit
{
    public $weight;

    public function __construct($name, $color, $weight)
    {
        $this->name = $name;
        $this->color = $color;
        $this->weight = $weight;
    }

    public function message()
    {
        echo "Is cherry a fruit or a berry?";
    }
}

$cherry = new Cherry("Cherry", "Red", "10 grams");

$cherry->message();
echo "<br>";
$cherry->intro();
echo "<br>";
echo "The weight of the cherry is " . $cherry->weight;

?>